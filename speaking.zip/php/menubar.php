<ul class="cl-nav">
    <li>
        <ul>
            <li><h3>Let's Collaborate!</h3></li>
            <li><a href="speaking.php" class="easef">Speaking</a></li>
            <li><a href="soon.php" class="easef">Brand Partners</a></li>
            <li><a href="general-inquiries.php" class="easef">Get In Touch</a></li>
        </ul>
    </li>

    <li>
        <ul>
            <li><h3>Resources</h3></li>
            <li><a href="soon.php" class="easef">Journal</a></li>
            <li><a href="soon.php" class="easef">Lavinia TV</a></li>
            <li><a href="soon.php" class="easef">Podcast</a></li>
            <li><a href="experts.php" class="easef">Experts</a></li>
            <li><a href="soon.php" class="easef">Downloads</a></li>
        </ul>
    </li>

    <li>
        <ul>
            <li><h3>Shop</h3></li>
            <li><a href="soon.php" class="easef">Products</a></li>
            <li><a href="soon.php" class="easef">Favorite Things</a></li>
        </ul>
    </li>
    
</ul>

<ul class="cl-nav">
    <li>
        <ul>
            <li><h3>About</h3></li>
            <li><a href="lavinia-errico.php" class="easef">Lavinia Errico</a></li>
            <li><a href="about-inside-out.php" class="easef">Inside Out</a></li>
        </ul>
    </li>

    <li>
        <ul>
            <li><h3>Events</h3></li>
            <li><a href="soon.php" class="easef">Upcoming</a></li>
            <li><a href="soon.php" class="easef">Recent</a></li>
        </ul>
    </li>

    <li>
        <ul>
            <li><a href="soon.php" class="easef">Cart</a></li>
            <li><a href="soon.php" class="easef">Search</a></li>
        </ul>
    </li>
</ul>
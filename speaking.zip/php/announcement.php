<!-- Announcement Section -->
<section class="announcement">
    <div class="wrapper">
    <h3>WATCH THE LATEST EPISODE OF <em>LAVINIA TV: ON RITUALS</em></h3>
</div>
</section>
<!-- Announcement Section -->